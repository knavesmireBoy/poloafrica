<meta name="description" content="<?php htmlout($page->content); ?>">
<meta property="og:title" content="<?php htmlout($page->meta_title); ?>">
<meta property="og:description" content="<?php htmlout($page->description); ?>">
<meta property="og:image" content="<?php htmlout($page->path); ?>">
<meta property="og:url" content="<?php htmlout($page->url); ?>">
<meta name="twitter:card" content="summary_large_image">