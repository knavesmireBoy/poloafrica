<footer>
        <div id="footer_girl">
			<a href="#"><img src="../images/resource/footer_girl.png"></a>
            <a href="."><b>tel: </b>(+27) 84 290 0000</a>
            <a href="mailto:info@poloafrica.com"><b>email: </b>info@poloafrica.com</a>
		</div>
        <div id="fb">
            <a href="https://www.instagram.com/poloafrica/" id="InstagramIcon" target="_blank"><img alt="Instagram icon" src="../images/resource/instagram_drop.png"></a> <a href="https://www.facebook.com/Poloafrica-Development-Trust-301491696614583/" id="FacebookBadge" target="_blank"><img alt="Facebook badge" src="../images/resource/like-us-on-facebook-png-black-1.png"></a>
        </div>
        <a href="mailto:photos@mwinsight.com">photos by <b>mark ward</b></a>
    </footer>
    <script src="../js/viewportSize.js"></script>
    <script src="../js/shims.js"></script>
    <script src="../js/underscore.js"></script>
    <script src="../js/eventing.js"></script>
    <script src="../js/classlist.js"></script>
    <script src="../js/global.js"></script>