<label for="dom_id">id</label>
    <input name="dom_id" id="dom_id" maxlength="20">
    <label for="alt">alt text/title</label>
    <input name="alt" id="alt">